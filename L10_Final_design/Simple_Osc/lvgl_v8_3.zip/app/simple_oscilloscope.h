#ifndef SIMPLE_OSCILLOSCOPE
#define SIMPLE_OSCILLOSCOPE

#include "ILI9341_Driver.h"
#include "ST7789_Driver.h"
#include "lcd_basic.h"
#include "stdio.h"

#include "lvgl.h"
#include "lv_port_disp_template.h"
#include "lv_port_indev_template.h"

void lv_simple_oscilloscope();
void lv_update_value(uint32_t value);

#endif