#include "simple_oscilloscope.h"

lv_obj_t * chart1;
lv_chart_series_t * ser1;

void lv_simple_oscilloscope()
{
    chart1 = lv_chart_create(lv_scr_act());
    lv_obj_set_size(chart1, 220, 230);
    lv_obj_center(chart1);
    lv_chart_set_type(chart1, LV_CHART_TYPE_LINE);
	
	lv_obj_set_style_size(chart1, 0, LV_PART_INDICATOR);
	lv_chart_set_point_count(chart1,50);
	
    lv_chart_set_div_line_count(chart1, 20, 20);

    ser1 = lv_chart_add_series(chart1, lv_palette_main(LV_PALETTE_RED), LV_CHART_AXIS_PRIMARY_Y);
	
	lv_obj_t * label = lv_label_create(lv_scr_act());
    lv_label_set_text(label, "Simple Oscilloscope");
    lv_obj_align_to(label, chart1, LV_ALIGN_OUT_TOP_MID, 0, -5);
}

void lv_update_value(uint32_t value)
{
	lv_chart_set_next_value(chart1, ser1, value);
}