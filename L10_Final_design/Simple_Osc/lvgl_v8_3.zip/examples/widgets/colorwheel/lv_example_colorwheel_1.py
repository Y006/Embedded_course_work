cw = lv.colorwheel(lv.scr_act(), True)
cw.set_size(200, 200)
cw.center()

