
Simple Switch
"""""""""""""""""""""""

.. lv_example:: widgets/switch/lv_example_switch_1
  :language: c

