
Span with custom styles
""""""""""""""""""""""""

.. lv_example:: widgets/span/lv_example_span_1
  :language: c

