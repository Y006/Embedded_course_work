
Simple Message box
"""""""""""""""""""

.. lv_example:: widgets/msgbox/lv_example_msgbox_1
  :language: c


